CREATE DATABASE adidas;
USE adidas;

CREATE TABLE sales 
(
    Retailer VARCHAR(50) NOT NULL,
    Retailer_ID INT NOT NULL,
    Region VARCHAR(30),
    State VARCHAR(30),
    City VARCHAR(30),
    Product VARCHAR(30),
    Price_per_Unit DECIMAL(10,2),
    Units_Sold INT,
    Total_Sales DECIMAL(10, 2),
    Operating_Profit DECIMAL(10, 2),
    Operating_Margin DECIMAL(10, 2),
    Sales_Method VARCHAR(30)
);
USE adidas;

SELECT * FROM sales;

---- General Sales Analysis

---- 1. What is the total sales revenue?

SELECT SUM(Total_Sales) as Total_sales_revenue
FROM sales;

---- 2. What is the average sales value?

SELECT AVG(Total_Sales) as Average_sales
FROM sales;

---- Customer and Regional Analysis

---- 3. Who is the top performing retailer by revenue?

SELECT  Retailer, Max(Total_Sales) as Highest_revenue
FROM sales 
GROUP BY Retailer
ORDER BY Highest_revenue Desc
LIMIT 1;

---- 4. Which region has the largest revenue?

SELECT Region, SUM(Total_Sales) as largest_revenue
FROM sales
GROUP BY Region
ORDER BY largest_revenue Desc
LIMIT 1;

---- 5. Which state has highest revenue?

SELECT State, SUM(Total_Sales) as highest_revenue
FROM sales
GROUP BY State
ORDER BY highest_revenue Desc
LIMIT 1;

---- 6. Which retailer have largest operating profit?

SELECT Retailer, MAX(Operating_Profit) as largest_operating_profit
FROM sales
GROUP BY Retailer
ORDER BY largest_operating_profit Desc
LIMIT 1;

---- 7. What is the average sales revenue per region?

SELECT Region, Avg(Total_Sales) as average_sales_revenue
FROM sales
GROUP BY Region
ORDER BY average_sales_revenue desc

---- 8. What is the average sales revenue per retailer?

SELECT Retailer, Avg(Total_Sales) as average_sales_revenue
FROM sales
GROUP BY Retailer
ORDER BY average_sales_revenue desc

---- 9. Which mode of sales method is most preferred in terms of total sales?

SELECT Sales_Method as most_preferred_method, MAX(Total_Sales) as total_sales
FROM sales
GROUP BY most_preferred_method
ORDER BY total_sales desc
LIMIT 1;

---- Product Analysis

---- 10. what are the total sales by product category?

SELECT Product, SUM(Total_Sales) as total_sales
FROM sales
GROUP BY Product
ORDER BY total_sales desc

---- 11. What is the revenue breakdown by product category and region?

SELECT Product, Region, SUM(Total_Sales) AS total_sales
FROM sales
GROUP BY Product, Region
ORDER BY Region, total_sales DESC;

---- 12. Which product contribute the most to the overall sales?

SELECT Product, SUM(Total_Sales) AS total_sales
FROM sales
GROUP BY Product
ORDER BY total_sales desc;

---- 13. Which product have largest operating margin?

SELECT Product, MAX(Operating_Margin) AS largest_operating_margin
FROM sales
GROUP BY Product
ORDER BY largest_operating_margin desc
LIMIT 1;